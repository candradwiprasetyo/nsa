<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"  />
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />
	<?php
	global $redux_webtocrat;
	echo ( !empty($redux_webtocrat['google-meta']) ) ? $redux_webtocrat['google-meta'] . "\n" : '';
	echo ( !empty($redux_webtocrat['bing-meta']) )   ? $redux_webtocrat['bing-meta']   . "\n" : '';
	echo ( !empty($redux_webtocrat['alexa-meta']) )  ? $redux_webtocrat['alexa-meta']  . "\n" : '';

	$favicon = ( !empty($redux_webtocrat['favicon']['url'])) ? $redux_webtocrat['favicon']['url'] : WEBTOCRAT_IMAGE_URI . '/favicon.ico';
	$logo    = (!empty($redux_webtocrat['logo']['url'])) ? $redux_webtocrat['logo']['url'] 		  : WEBTOCRAT_IMAGE_URI . '/logo.png';
	?>
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo $favicon; ?>">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

	<div class="wrapall">
		
		<div class="wrapTop rich_text">
			<div class="second_menu">
				<div class="inner">

					<div class="logo">
						<a href="<?php echo home_url(); ?>" title="<?php bloginfo( 'name' ); ?>">
							<img src="<?php echo $logo; ?>" alt="<?php bloginfo( 'name' ); ?>"/>
						</a>
					</div>

					<?php
						// Top Menu
						wp_nav_menu( array(
							'theme_location'    => 'top-menu',
							'depth'             => 1,
							'container'         => false,
							'menu_class'        => 'top-menu',
							'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
							'walker'            => new wp_bootstrap_navwalker()
						) );

						// Main Menu
						wp_nav_menu( array(
							'theme_location'    => 'main-menu',
							'depth'             => 2,
							'container'         => false,
							'menu_class'        => 'main_menu navigasi',
							'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
							'walker'            => new wp_bootstrap_navwalker()
						) );
					?>

					<div class="clear_fix"></div>
				</div>
			</div>
		</div><!-- end.wrapTop -->