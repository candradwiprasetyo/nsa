<?php
/**
Template Name: Page - Home
*/

get_header(); ?>
		
	<div class="wrapHeader header_home rich_text">
		<div class="inner">


			<div class="select_level sl_2">
				<a href="" title="">
					<img class="imgmlhover" src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/hoverlinksch1.jpg" alt="" />
					TODDLER / KINDERGARTEN
				</a>
			</div>


			<div class="select_level sl_3">
				<a href="" title="">
					<img class="imgmlhover" src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/hoverlinksch2.jpg" alt="" />
					ELEMENTARY SCHOOL
				</a>
			</div>


			<div class="select_level sl_4">
				<a href="" title="">
					<img class="imgmlhover" src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/hoverlinksch3.jpg" alt="" />
					JUNIOR HIGH SCHOOL
				</a>
			</div>


			<div class="select_level sl_5">
				<a href="" title="">
					<img class="imgmlhover" src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/hoverlinksch4.jpg" alt="" />
					HIGH SCHOOL
				</a>
			</div>


			<div class="bannerSlide">
				<div class="wrapin_banner">
					<div class="in_banner">
						<div class="quote">
							<h4>Senior High Research Exhibition</h4>
						</div>
						<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/imgbanner1.jpg" alt="" />
					</div>
					<div class="in_banner">
						<div class="quote">
							<h4>Student Orchestra with Addie MS</h4>
						</div>
						<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/imgbanner2.jpg" alt="" />
					</div>
				</div>
				<div id="nav_lt"></div>
			</div>
			<div class="select"><h1>Select <br />Level</h1></div>
			<div class="bannerred">&nbsp;</div>
			<div class="banneryellow"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/banneryellow.png" alt="" /></div>
			<div class="clear_fix"></div>
			<div class="textbanner"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/textbanner.png" alt="" /></div>
			<div class="star"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/star.png" alt="" /></div>
		</div>
	</div><!-- end.wrapTop -->

	<div class="wrapContent rich_text">

		<div class="blockcontent">
			<div class="latestUpdate">
				<div class="inner">
					<div class="newshome">
						<h1>Latest</h1>
						<h2>Update</h2>
						<div class="image">
							<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/newsHome.jpg" alt="" />
						</div>
						<div class="text">
							<h1>Studi Ekskursi</h1>
							<p>NSA mengadakan kegiatan Studi Ekskursi dengan tujuan untuk meningkatkan pengetahuan dan wawasan para siswa. NSA mengadakan kegiatan Studi Ekskursi dengan tujuan untuk meningkatkan pengetahuan dan wawasan para siswa.</p>
						</div>
						<a class="more" href="<?php echo home_url(); ?>/studi-ekskursi/" title="Studi Ekskursi">Read More</a>
					</div>
					<div class="welcome">
						<div class="contentW">
							<div class="photo">
								<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/photoW.jpg" alt="Kresnayaha Yahya" />
							</div>
							<div class="quoteW">
								<p>"Karena Tuhan selalu mengajak manusia berubah akal budinya, untuk menjadi manusia yang makin sempurna dan paham kehendak Tuhan. Perubahan harus disikapi sebagai sebuah realita. Hanya yang berubah akan ikut menjadi penentu masa depan" <br /><br /> - Kresnayaha Yahya -</p>
							</div>
						</div>
					</div>
					<div class="clear_fix"></div>
				</div>
				<div class="buble1"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/buble1.png" alt="" /></div>
				<div class="buble2"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/buble2.png" alt="" /></div>
			</div>
		</div>

		<div class="blockcontent">
			<div class="latestGallery">
				<div class="inner">
					<h1>Latest</h1>
					<h2>Gallery</h2>
					<div class="wrapGH">


						<div class="galleryHome">
							<div class="galleryHomeIn">
								<a class="more moreGal" href="" title="View Lorem Ipsum Gallery">View</a>
								<div class="homeG overlaM">
									<h4>Toddler</h4>
								</div>
								<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/GH0.jpg" alt="Lorem Ipsum" />
							</div>
						</div>


						<div class="galleryHome">
							<div class="galleryHomeIn">
								<a class="more moreGal" href="" title="View Lorem Ipsum Gallery">View</a>
								<div class="homeG overlaM">
									<h4>Elementary School</h4>
								</div>
								<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/GH1.jpg" alt="Lorem Ipsum" />
							</div>
						</div>


						<div class="galleryHome">
							<div class="galleryHomeIn">
								<a class="more moreGal" href="" title="View Lorem Ipsum Gallery">View</a>
								<div class="homeG overlaM">
									<h4>Junior High School</h4>
								</div>
								<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/GH2.jpg" alt="Lorem Ipsum" />
							</div>
						</div>


						<div class="galleryHome">
							<div class="galleryHomeIn">
								<a class="more moreGal" href="" title="View Lorem Ipsum Gallery">View</a>
								<div class="homeG overlaM">
									<h4>High School</h4>
								</div>
								<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/GH3.jpg" alt="Lorem Ipsum" />
							</div>
						</div>


					</div>
					<div class="clear_fix"></div>
				</div>
			</div>
		</div>

		<div class="blockcontent">
			<div class="allaccess">
				<div class="inner">
					<div class="newsletter">
						<h1>Join Our Newsletter</h1>
						<img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/iconewsletter.png" alt="" />
						<form action="">
							<input class="text" type="text" placeholder="enter your email address.." />
							<input class="button" type="button" value="Subscribe" />
						</form>
					</div>
					<div class="separator">&nbsp;</div>
					<ul class="linkaccess">
						<li class="icoa1">
							<a href="#" title="">
								<img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/icoa1.png" alt="" /><br />
								Inquiry Form
							</a>
						</li>
						<li class="icoa2">
							<a href="#" title="">
								<img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/icoa2.png" alt="" /><br />
								E-Learning <br /> &nbsp;
							</a>
						</li>
						<li class="icoa3">
							<a href="#" title="">
								<img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/icoa3.png" alt="" /><br />
								Chat with NSA
							</a>
						</li>
					</ul>
					<div class="clear_fix"></div>
				</div>
			</div>
		</div>
		
		<div class="blockcontent">
			<div class="allpartner">
				<div class="inner">
					<div class="partnership">
						<h1>Partnership :</h1>
						<div class="logoPart">
							<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/imgPartnership1.jpg" alt="" />
						</div>
						<div class="logoPart">
							<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/imgPartnership2.jpg" alt="" />
						</div>
						<div class="logoPart">
							<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/imgPartnership2.jpg" alt="" />
						</div>
					</div>
					<div class="addressSocmed">
						<h1>Nation Star Academy</h1>
						<h5>Jl. Dharmahusada Indah Barat VI/1 Surabaya</h5>
						<ul>
							<li><h4>Follow Us :</h4></li>
							<li><a href="https://www.facebook.com" title=""><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/fb.png" alt="" /></a></li>
							<li><a href="https://www.twitter.com" title=""><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/tw.png" alt="" /></a></li>
							<li><a href="https://www.youtube.com" title=""><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/yt.png" alt="" /></a></li>
						</ul>
					</div>
					<div class="clear_fix"></div>
				</div>
			</div>
		</div>
	</div><!-- end.wrapContent -->

<?php get_footer(); ?>