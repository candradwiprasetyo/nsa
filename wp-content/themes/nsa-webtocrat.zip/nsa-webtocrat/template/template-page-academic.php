<?php
/**
Template Name: Page - Academic
*/

get_header(); ?>
		
	<div class="wrapHeader rich_text">
		<div class="headerpage">
			<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/header1.jpg" alt="" />
		</div>
	</div><!-- end.wrapTop -->
		
	<div class="wrapContent rich_text">
		<div class="wrapbreadcrumb">
			<div class="inner">
				<ul class="breadcrumb">
					<li><a class="homeb" href="<?php echo home_url(); ?>/" title="Homr">&nbsp;</a></li>
					<li class="arrow">&nbsp;</li>
					<li><a href="<?php echo home_url(); ?>/academic" title="Academic">Academic</a></li>
				</ul>
			</div>
		</div>
		<div class="inner">
			<div class="wrapcontentpage">
				<div class="leftside">
					<div class="nsasubmenu bg_achieve">
						<img class="htp3" src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/sunAcademy.png" alt="" />
					</div>
					<div class="nsaleft"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/bannergreen.png" alt="" /></div>
				</div>
				<div class="rightside">
					<h1>Academic</h1>
					<h2></h2>
					<div class="wrap_inner_content">
						<div class="wrapAcademic">
							<div class="box_academic ba_y1">
								<div class="titleacademic ba_y2"><h4>Daycare &amp; Baby Class</h4></div>
								<div class="textacademic">
									<p>Phonics, English Fun. Art & Craft, Character Building, Life Skills, Computer. Experience, Music, Drawing, Swimming, Music and Movement, Mandarin, Indonesia, Mathematics, PE (Physical Education), Dancing</p>
								</div>
								<div class="clear_fix"></div>
							</div>
							<div class="box_academic ba_o1">
								<div class="titleacademic ba_o2"><h4>Playgroup/<br />Kindergarten</h4></div>
								<div class="textacademic">
									<p>Phonics, English Fun. Art & Craft, Character Building, Life Skills, Computer. Experience, Music, Drawing, Swimming, Music and Movement, Mandarin, Indonesia, Mathematics, PE (Physical Education), Dancing</p>
								</div>
								<div class="clear_fix"></div>
							</div>
							<div class="box_academic ba_r1">
								<div class="titleacademic ba_r2"><h4>Elementary School</h4></div>
								<div class="textacademic">
									<p>Agama, Pkn, Bahasa Indonesia, Matematika, IPA, IPS, Pendidikan Jasmani, SBK, Muatan Lokal, Bahasa Inggris, Bahasa Daerha, Bahasa Mandarin Komputer</p>
								</div>
								<div class="clear_fix"></div>
							</div>
							<div class="box_academic ba_g1">
								<div class="titleacademic ba_g2"><h4>Middle <br />School</h4></div>
								<div class="textacademic">
									<p>Pendidikan Agama, Pendidikan Kewarganegaraan, Bahasa Indonesia, Bahasa Inggris, Matematika, IPA(Ilmu Pengetahuan Alam), IPS (Ilmu Pengetahuan Sosial), Seni Musik dan Seni Rupa, Pendidikan Jasmani, Olah raga dan Kesehatan, Teknologi Informasi & Komunikasi, Bahasa Daerah, Elektro dan Tata Boga, Bahasa Tionghoa, Character Building, Robotik, Sport Dance</p>
								</div>
								<div class="clear_fix"></div>
							</div>
							<div class="box_academic ba_b1">
								<div class="titleacademic ba_b2"><h4>High <br />School</h4></div>
								<div class="textacademic">
									<p>Pendidikan Agama, Pendidikan Kewarganegaraan, Bahasa Indonesia, Bahasa Inggris, Matematika, IPA(Ilmu Pengetahuan Alam), IPS (Ilmu Pengetahuan Sosial), Seni Musik dan Seni Rupa, Pendidikan Jasmani, Olah raga dan Kesehatan, Teknologi Informasi & Komunikasi, Bahasa Daerah, Elektro dan Tata Boga, Bahasa Tionghoa, Character Building, Robotik, Sport Dance</p>
								</div>
								<div class="clear_fix"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="clear_fix"></div>
			</div>
		</div>
		<div class="ornamentP"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/ornamentP.png" alt="" /></div>
	</div><!-- end.wrapContent -->

<?php get_footer(); ?>