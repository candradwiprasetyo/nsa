<?php
/**
Template Name: Page - Values
*/

get_header(); ?>
		
	<div class="wrapHeader rich_text">
		<div class="headerpage">
			<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/header1.jpg" alt="" />
		</div>
	</div><!-- end.wrapTop -->
		
	<div class="wrapContent rich_text">
		<div class="wrapbreadcrumb">
			<div class="inner">
				<ul class="breadcrumb">
					<li><a class="homeb" href="<?php echo home_url(); ?>/" title="Home">&nbsp;</a></li>
					<li class="arrow">&nbsp;</li>
					<li><a href="<?php echo home_url(); ?>/history" title="Profile">Profile</a></li>
					<li class="arrow">&nbsp;</li>
					<li><a href="<?php echo home_url(); ?>/values" title="Values">Values</a></li>
				</ul>
			</div>
		</div>
		<div class="inner">
			<div class="wrapcontentpage">

				<div class="leftside">
					<div class="nsasubmenu bg_profile">
						<img class="htp1" src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/sunProfil.png" alt="Profile" />
						<!--<h1 class="htp1">Profile</h1>-->
						<ul>
							<li><a href="<?php echo home_url(); ?>/history" title="History">History</a></li>
							<li><a href="<?php echo home_url(); ?>/vision-mission" title="Vision & Mission">Vision & Mission</a></li>
							<li><a class="active" href="<?php echo home_url(); ?>/values" title="Values">Values</a></li>
							<li><a href="<?php echo home_url(); ?>/board-of-trustees" title="Board of Trustees">Board of Trustees</a></li>
							<li><a href="<?php echo home_url(); ?>/management" title="Management">Management</a></li>
							<li><a href="<?php echo home_url(); ?>/gm-division" title="GM & Division">GM & Division</a></li>
						</ul>
					</div>
					<div class="nsaleft"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/bannergreen.png" alt="" /></div>
				</div>
				
				<div class="rightside">
					<h1>Values</h1>
					<h2></h2>
					<div class="wrap_inner_content">
						<div class="rs_left">
							<h3>Science</h3>
							<h5>Mengembangkan pengetahuan, ketrampilan dan sikap keingintahuan terhadap alam dan lingkungannya; berpikir kritis, logis dan lateral; mencintai kebenaran ilmu pengetahuan untuk melahirkan karya kreatif  sesuai dengan tahapan jenjang pendidikan.</h5>
						</div>
						<div class="rs_right">
							<div class="wrapimg_circle icsize_2">
								<div class="img_circle">
									<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/science_values.jpg" alt="" />
								</div>
							</div>
						</div>
						<div class="clear_fix"></div>
					</div>
					<div class="wrap_inner_content">
						<div class="rs_left">
							<div class="wrapimg_circle icsize_2">
								<div class="img_circle">
									<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/technology_values.jpg" alt="" />
								</div>
							</div>							
						</div>
						<div class="rs_right">
							<h3>Technology</h3>
							<h5>Membangun komunitas sekolah yang IT Literate; mengembangkan pengetahuan dan ketrampilan pemanfaatan  informasi dan teknologi komunikasi (ICT) untuk mengakses sumber-sumber pengetahuan;  membangun jejaring untuk berkontribusi aktif dan positif secara global.</h5>
						</div>
						<div class="clear_fix"></div>
					</div>
					<div class="wrap_inner_content">
						<div class="rs_left">
							<h3>Art</h3>
							<h5>Mengembangkan potensi keunikan bakat setiap siswa melalui program pengembangan yang berkelanjutan di setiap jenjang; membangun suasana belajar yang menumbuhkembangkan bakat dan rasa percaya diri siswa untuk menghasilkan karya-karya kultural bagi hidup serta peradaban bangsa.</h5>
						</div>
						<div class="rs_right">
							<div class="wrapimg_circle icsize_2">
								<div class="img_circle">
									<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/art_values.jpg" alt="" />
								</div>
							</div>
						</div>
						<div class="clear_fix"></div>
					</div>
					<div class="wrap_inner_content">
						<div class="rs_left">
							<div class="wrapimg_circle icsize_2">
								<div class="img_circle">
									<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/religion_values.jpg" alt="" />
								</div>
							</div>							
						</div>
						<div class="rs_right">
							<h3>Religion</h3>
							h5>Membangun keunggulan sikap dan karakter siswa dan membentuk siswa menjadi pribadi yang bertanggung jawab, memiliki etika, nilai moral dan karakter yang baik.</h5>
						</div>
						<div class="clear_fix"></div>
					</div>
				</div>
				<div class="clear_fix"></div>
			</div>
		</div>
		<div class="ornamentP"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/ornamentP.png" alt="" /></div>
	</div><!-- end.wrapContent -->

<?php get_footer(); ?>