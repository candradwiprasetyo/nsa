<?php
/**
Template Name: Page - Sitemap
*/

get_header(); ?>
		
	<div class="wrapHeader rich_text">
		<div class="headerpage">
			<img src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/header1.jpg" alt="" />
		</div>
	</div><!-- end.wrapTop -->
		
	<div class="wrapContent rich_text">
		<div class="wrapbreadcrumb">
			<div class="inner">
				<ul class="breadcrumb">
					<li><a class="homeb" href="<?php echo home_url(); ?>/" title="Home">&nbsp;</a></li>
					<li class="arrow">&nbsp;</li>
					<li><a href="<?php echo home_url(); ?>/sitemap" title="Sitemap">Sitemap</a></li>
				</ul>
			</div>
		</div>
		<div class="inner">
			<div class="wrapcontentpage">
				<div class="leftside">
					<div class="nsasubmenu bg_career">
						<img class="htp3" src="<?php echo home_url(); ?>/wp-content/uploads/2015/07/sunSitemap.png" alt="" />
					</div>
					<div class="nsaleft"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/bannergreen.png" alt="" /></div>
				</div>
				<div class="rightside">
					<div class="wrap_inner_content">
						<div class="wrapSitemap">
							<div class="sitemap">
								<a href="<?php echo home_url(); ?>/history" title="Profile"><h2>Profile</h2></a>
								<ul>
									<li><a href="<?php echo home_url(); ?>/history" title="History">History</a></li>
									<li><a href="<?php echo home_url(); ?>/vision-mission" title="Vision & Mission">Vision & Mission</a></li>
									<li><a href="<?php echo home_url(); ?>/values" title="Values">Values</a></li>
									<li><a href="<?php echo home_url(); ?>/board-of-trustees" title="Board of Trustees">Board of Trustees</a></li>
									<li><a href="<?php echo home_url(); ?>/management" title="Management">Management</a></li>
									<li><a href="<?php echo home_url(); ?>/gm-division" title="GM & Division">GM & Division</a></li>
								</ul>
							</div>
							<div class="sitemap">
								<a href="<?php echo home_url(); ?>/achievement" title="Achievement"><h2>Achievement</h2></a>
							</div>
							<div class="sitemap">
								<a href="<?php echo home_url(); ?>/academic" title="Academic"><h2>Academic</h2></a>
								<ul>
									<li><a href="<?php echo home_url(); ?>/academic" title="Academic">Academic</a></li>
									<li><a href="<?php echo home_url(); ?>/non-academic" title="Non Academic">Non Academic</a></li>
									<li><a href="<?php echo home_url(); ?>/extracurricular" title="Extracurricular">Extracurricular</a></li>
								</ul>
							</div>
							<div class="clear_fix"></div>
						</div>
						<div class="wrapSitemap">
							<div class="sitemap">
								<a href="<?php echo home_url(); ?>/admission" title="Admission"><h2>Admission</h2></a>
							</div>
							<div class="sitemap">
								<a href="<?php echo home_url(); ?>/parents-corner" title="Parents Corner"><h2>Parents Corner</h2></a>
							</div>
							<div class="sitemap">
								<a href="<?php echo home_url(); ?>/contact-us" title="Contact Us"><h2>Contact Us</h2></a>
							</div>
							<div class="clear_fix"></div>
						</div>
						<div class="wrapSitemap">
							<div class="sitemap">
								<a href="<?php echo home_url(); ?>/site-nsa" title="Sitemap"><h2>Sitemap</h2></a>
							</div>
							<div class="sitemap">
								<a href="<?php echo home_url(); ?>/career" title="Career"><h2>Career</h2></a>
							</div>
							<div class="clear_fix"></div>
						</div>
					</div>
				</div>
				<div class="clear_fix"></div>
			</div>
		</div>
		<div class="ornamentP"><img src="<?php echo WEBTOCRAT_IMAGE_URI; ?>/ornamentP.png" alt="" /></div>
	</div><!-- end.wrapContent -->

<?php get_footer(); ?>