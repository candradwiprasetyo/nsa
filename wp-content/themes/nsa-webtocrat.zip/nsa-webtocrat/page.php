<?php get_header(); ?>

ada

<?php get_footer(); ?>