<?php
$main_url = "http://localhost/download_nsa/";
$con = mysql_connect("localhost", "root", "");
mysql_select_db("nsa_real", $con );
?>