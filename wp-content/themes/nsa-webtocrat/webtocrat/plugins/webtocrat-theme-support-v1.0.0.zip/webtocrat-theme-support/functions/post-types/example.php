<?php

/**

----------------------------------------------------------------------------------------------------

	Filename	: example.php
	Location	: ../functions/post-types/
	Author		: BAS - Webtocrat Motion
	Version		: 1.0.0
	Description	: Example Post Type Functions

----------------------------------------------------------------------------------------------------

	Table Of Contents
	
	1.0 - Register example category
    2.0 - Register example tag
    3.0 - Register example post type
    4.0 - Edit example columns
    5.0 - Example custom columns
    6.0 - Example sortable columns
    7.0 - Custom action row
    8.0 - Example redirect

----------------------------------------------------------------------------------------------------

*/


/**
----------------------------------------------------------------------------------------------------
    1.0 - Register example category
----------------------------------------------------------------------------------------------------
*/
$args_category = array(
    'label'                         => 'Categories', 
    'singular_label'                => 'Category', 
    'public'                        => true,
    'hierarchical'                  => true,
    'show_ui'                       => true,
    'show_in_nav_menus'             => false,
    'args'                          => array( 'orderby' => 'term_order' ),
    'rewrite'                       => false,
    'query_var'                     => true
);
register_taxonomy( 'example-category', 'example', $args_category );


/**
----------------------------------------------------------------------------------------------------
	2.0 - Register example tag
----------------------------------------------------------------------------------------------------
*/
$args_tag = array(
    'label' 						=> 'Tags', 
    'singular_label' 				=> 'Tag', 
    'public'                        => true,
    'hierarchical'                  => true,
    'show_ui'                       => true,
    'show_in_nav_menus'             => false,
    'args'                          => array( 'orderby' => 'term_order' ),
    'rewrite'                       => false,
    'query_var'                     => true
);
register_taxonomy( 'example-tag', 'example', $args_tag );


/**
----------------------------------------------------------------------------------------------------
	3.0 - Register example post type
----------------------------------------------------------------------------------------------------
*/
function example_register() {

	$menu_icon = ( floatval( get_bloginfo( 'version' ) ) >= '3.8' ) ? 'dashicons-lightbulb' : NULL;

    $labels = array(
        'name'               => _x('Examples',          'post type general name',   'webtocrat' ),
        'singular_name'      => _x('Example',           'post type singular name',  'webtocrat' ),
        'add_new'            => _x('Add New',           'example item',             'webtocrat' ),
        'add_new_item'       => __('Add New Example',                               'webtocrat' ),
        'edit_item'          => __('Edit Example',                                  'webtocrat' ),
        'new_item'           => __('New Example',                                   'webtocrat' ),
        'view_item'          => __('View Example',                                  'webtocrat' ),
        'search_items'       => __('Search Example',                                'webtocrat' ),
        'not_found'          => __('No example have been added yet',                'webtocrat' ),
        'not_found_in_trash' => __('Nothing found in Trash',                        'webtocrat' ),
        'parent_item_colon'  => ''
    );

    $args = array(
        'labels'            => $labels,  
        'public'            => true,  
        'show_ui'           => true,
        'show_in_menu'      => true,
        'show_in_nav_menus' => false,
        'rewrite'           => array('slug' => 'example'),
        'supports'          => array('title', 'editor', 'thumbnail'), // title, editor, author, thumbnail, excerpt, trackbacks, custom-fields, comments, revisions, page-attributes, post-formats
        'has_archive'       => true,
        'menu_icon'         => $menu_icon,
        'taxonomies'        => array('example-category'),
        'menu_position'     => 28,
       );  
  
    register_post_type( 'example' , $args );  
}  
add_action( 'init', 'example_register' );


/**
----------------------------------------------------------------------------------------------------
	4.0 - Edit example columns
----------------------------------------------------------------------------------------------------
*/
function example_edit_columns($columns){  
    $columns = array(
        'cb'               => '<input type=\'checkbox\' />',
        'title'            => __('Name',     'webtocrat'),
        'example_category' => __('Category', 'webtocrat'),
        'example_tag'      => __('Tag', 'webtocrat'),
        'thumbnail'        => __('Thumbnail', 'webtocrat'),
        'custom_field'     => __('Custom Field', 'webtocrat'),
        'date'             => __('Date', 'webtocrat'),
    );  

    return $columns;  
}
add_filter( 'manage_edit-example_columns', 'example_edit_columns' ); 


/**
----------------------------------------------------------------------------------------------------
	5.0 - Example custom columns
----------------------------------------------------------------------------------------------------
*/
function example_custom_columns($column){  
        global $post;  
        switch ($column) {
            case 'example_category':
                $terms_category = get_the_terms( $post->ID, 'example-category' );
                if ( $terms_category && ! is_wp_error( $terms_category ) ) {
                    $example_category_links = array();
                    foreach ( $terms_category as $term_category ) {
                        $example_category_links[] = $term_category->name;
                    }
                    $example_category = join( ", ", $example_category_links );
                    echo $example_category;
                }
            break;
            case 'example_tag':
                $terms_tag = get_the_terms( $post->ID, 'example-tag' );
                if ( $terms_tag && ! is_wp_error( $terms_tag ) ) {
                    $example_tag_links = array();
                    foreach ( $terms_tag as $term_tag ) {
                        $example_tag_links[] = $term_tag->name;
                    }
                    $example_tag = join( ", ", $example_tag_links );
                    echo $example_tag;
                }
            break;
            case 'custom_field':
                echo get_post_meta( $post->ID, 'custom_field', true );
            break;
            case 'thumbnail':
                echo the_post_thumbnail( 'thumbnail' );
            break;
        }  
}
add_action( 'manage_example_posts_custom_column', 'example_custom_columns' );


/**
----------------------------------------------------------------------------------------------------
    6.0 - Example sortable columns
----------------------------------------------------------------------------------------------------
*/
function provide_sortable_columns( $columns ) {
    $columns['example_category'] = 'example_category';
    $columns['example_tag']      = 'example_tag'; 
    return $columns;
}
add_filter( 'manage_edit-example_sortable_columns', 'provide_sortable_columns' );


/**
----------------------------------------------------------------------------------------------------
    7.0 - Custom action row
----------------------------------------------------------------------------------------------------
*/
function example_action_row($actions, $post){
    //check for your post type
    if ( $post->post_type == "example" ){
        unset( $actions['view'] );
        unset( $actions['trash'] );
        unset( $actions['edit'] );
        unset( $actions['inline hide-if-no-js'] );        
    }
    return $actions;
}
add_filter('post_row_actions','example_action_row', 10, 2);


/**
----------------------------------------------------------------------------------------------------
    8.0 - Example redirect
----------------------------------------------------------------------------------------------------
*/
function example_context_redirect() {
    if ( get_query_var( 'post_type' ) == 'example' ) {
        global $wp_query;
        $wp_query->is_home     = false;
        $wp_query->is_single   = false;
        $wp_query->is_singular = false;
        $wp_query->is_404      = true;
    }
}
add_action( 'template_redirect', 'example_context_redirect' );