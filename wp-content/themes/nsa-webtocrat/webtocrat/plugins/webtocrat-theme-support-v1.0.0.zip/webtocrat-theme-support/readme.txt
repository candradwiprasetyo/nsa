===== Plugin to support WEBTOCRAT Framework. =====

Thank you for choosing to use WEBTOCRAT Framework!


Format : 1.0.0
		 Major.Minor.Patch

===== Changelog =====

= 1.0.0 =
* First version!